<!DOCTYPE html>
<html>
<head>
	<title>Animal Information</title>
</head>
<body onload="GenerateCaptcha();">
	<form action="process.php" method="post" enctype="multipart/form-data">
	<div style="background-color: maroon; margin-left: 200px; margin-right: 200px">
		<h1 style="color: White; text-align: center;">Animal Information</h1>
		<div style="border: double; background-color: lightblue">
			<div style="margin-top: 10px;margin-bottom: 10px;">
				<label for="Animalname" style="font-family: TimeNewRoman; margin-left: 300px;"><b>Name of the Animal:</b></label>
				<input type="text" name="aname" id="aname" style="width: 230px" required>
				<input type="hidden" name="adate" id="adate" value="CurrentDate">
			</div>
			<div style="margin-top: 10px;margin-bottom: 10px;">
				<label for="Category" style="font-family: TimeNewRoman; margin-left: 300px"><b>Category:</b></label>
				<select name="category" id="category" style="margin-left: 74px; width: 238px;" required>
					<option value="">Select</option>
					<option value="Herbivores">Herbivores</option>
					<option value="Omnivores">Omnivores</option>
					<option value="Carnivores">Carnivores</option>
				</select>
			</div>
			<div style="margin-top: 10px;margin-bottom: 10px;">
				<label for="file" style="font-family: TimeNewRoman; margin-left: 300px;"><b>Image:</b></label>
				<input type="file" name="file" id="file" style="margin-left: 95px; width: 238px" required>
			</div>
			<div style="margin-top: 10px;margin-bottom: 10px;">
				<label for="Description" style="font-family: TimeNewRoman; margin-left: 300px;"><b>Description:</b></label>
				<textarea name="description" id="description" style="margin-left: 60px; width: 230px" required></textarea>
			</div>
			<div style="margin-top: 10px;margin-bottom: 10px;">
				<label for="Life" style="font-family: TimeNewRoman; margin-left: 300px"><b>Life Expectancy:</b></label>
				<select name="life" id="life" style="margin-left: 29px; width: 238px;" required>
					<option value="">Select</option>
					<option value="0-1 Years">0-1 Year</option>
					<option value="1-5 Years">1-5 Years</option>
					<option value="5-10 Years">5-10 Years</option>
					<option value="10+ Years">10+ Years</option>
				</select>
			</div>
			<div style="margin-top: 10px;margin-bottom: 10px;">
				<label for="Captcha" style="font-family: TimeNewRoman; margin-left: 300px;"><b>Captcha:</b></label>
				<input type="text" id="txtCaptcha" style="margin-left: 80px; border: none; font-weight: bold; font-size: 20px; font-family: Modern; width: 113px">
				<input type="text" name="captcha" id="captcha" style="width: 113px">
			</div>

			<div style="margin-top: 10px;margin-bottom: 10px;">
				<input type="submit" name="submit" value="Submit" style="margin-left: 450px" onclick="ValidCaptcha();">
			</div>

		</div>
	</div>
	</form>
</body>
<script type="text/javascript">
	//Code to set current date in hidden date field
    var today = new Date();
	var dd = String(today.getDate()).padStart(2, '0');
	var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
	var yyyy = today.getFullYear();
	today = yyyy + '-' + mm + '-' + dd;
	document.getElementById("adate").value = today;
	//Function for Generate Captcha
	function GenerateCaptcha() 
	{  
        var chr1 = Math.ceil(Math.random() * 10) + ''; /*Math.random returns a random number between 0 to 1 and Math.ceil always rounds a number up to the next largest integer*/ 
        var chr2 = Math.ceil(Math.random() * 10) + '';  
        var chr3 = Math.ceil(Math.random() * 10) + '';  
  
        var str = new Array(4).join().replace(/(.|$)/g, function () { return ((Math.random() * 36) | 0).toString(36)[Math.random() < .5 ? "toString" : "toUpperCase"](); });  
        var captchaCode = str + chr1 + ' ' + chr2 + ' ' + chr3;  
        document.getElementById("txtCaptcha").value = captchaCode  
    }  
    //Validating Captcha Function 
    function ValidCaptcha() 
    {  
        var str1 = removeSpaces(document.getElementById('txtCaptcha').value);  
        var str2 = removeSpaces(document.getElementById('captcha').value);
        //Cpmparing two text fields  
        if(!(str1 == str2)) 
           	alert('Please enter correct captcha'); 
    }  
    /* Remove spaces from Captcha Code */  
    function removeSpaces(string) 
    {  
        return string.split(' ').join(''); /*split the string by the space into an array by using split() string method and concatenate all elements into a string by using the join() method and return it */ 
    }  
</script>
</html>