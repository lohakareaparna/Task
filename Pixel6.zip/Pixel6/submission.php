<?php
	//Code For Filter Records
	if (isset($_POST['search'])) 
	{
		$ValueToSearch = $_POST['ValueToSearch'];
		$valueToSearch = $_POST['valueToSearch'];
		$query = "SELECT name, category, image, description, life, adate FROM animalinfo WHERE category LIKE '%".$ValueToSearch."%' AND life LIKE '%".$valueToSearch."%'";
		$search_result = filter_Table($query);
	}
	else
	{
		$query = "SELECT name, category, image, description, life, adate FROM animalinfo ORDER BY adate DESC, category ASC";
		$search_result = filter_Table($query);
	}
	function filter_Table($query)
	{
		$conn=mysqli_connect("localhost","root");
 		mysqli_select_db($conn,"animaldata");
 		$filter_result = mysqli_query($conn,$query);
 		return $filter_result;
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Animal Information</title>
	<style type="text/css">
		table, thead, th, tbody, tr, td
		{
			border: 1px solid black;  
    		border-collapse: collapse; 
    		padding: 5px;
		}
		td{
			column-width: 300px;
			text-align: center;
			font-size: 18px;
		}
		td.td1
		{
			column-width: 200px;
			text-align: center;
		
		}
		th
		{
			font-size: 22px;
			color: Grey;
		}
	</style>
</head>

<body>
	<form action="submission.php" method="post">
		<div style="background-color: maroon; margin-left: 150px; margin-right: 150px;">
		<h1 style="color: White; text-align: center; padding: 5px;">Animal Information</h1>
		<label id="counter" style="color: White;"><b>
			<?php
			//Create file named count.php. Upload this file to the directory. 
			$handle = fopen("count.php", "r"); //open file using fopen() function in read mode
			if(!$handle) { 
			    echo "could not open the file"; 
			} else { 
			    $counter =(int )fread($handle,20); /*The fread() reads from an open file. */
			        fclose($handle); //fclose function is used to close the file
			        $counter++; 
			        echo"Number of visitors : ". $counter . "" ; 
			    $handle = fopen("count.php", "w" ); //open the file in write mode 
			    
			    fwrite($handle,$counter); //Write Counter value in file using fwrite() function
			    fclose ($handle); 
			}
			?></b>
		</label> 
		
		<select name="ValueToSearch" id="ValueToSearch" style="margin-left: 400px; width: 200px;">
			<option value="">Search By Category</option>
			<option value="Herbivores">Herbivores</option>
			<option value="Omnivores">Omnivores</option>
			<option value="Carnivores">Carnivores</option>
		</select>
		<select name="valueToSearch" id="valueToSearch" style="width: 200px;">
			<option value="">Search By Life Expectancy</option>
			<option value="0-1 Years">0-1 Year</option>
			<option value="1-5 Years">1-5 Years</option>
			<option value="5-10 Years">5-10 Years</option>
			<option value="10+ Years">10+ Years</option>
		</select>
		<input type="submit" name="search" value="Filter">
		
		
		<div style="border: double; background-color: white;">
		<table>
			<thead>
				<th>Animal Photo</th>
				<th>Name</th>
				<th>Category</th>
				<th>Description</th>
				<th>Life Expectancy</th>
			</thead>
			<tbody>
		<?php
			while($row=mysqli_fetch_assoc($search_result)) 
			{
        ?>
				<tr style="border-style: solid;">
					<td><img src='<?php echo $row["image"];  ?>' style="height: 100px; width: 250px;"></td>
					<td class="td1"><b><?php echo $row["name"];?></b></td>
					<td class="td1"><b><?php echo $row["category"];?></b></td>
					<td class="td1"><b><?php echo $row["description"];?></b></td>
					<td class="td1"><b><?php echo $row["life"];?></b></td>
				</tr>
			<?php
			}
			?>
			</tbody>
		</table>
		</div>
	</form>
</body>
<script type="text/javascript">
	
</script>
</html>
