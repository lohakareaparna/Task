<?php
//Connection to the Mysql Database
	$conn=mysqli_connect("localhost","root");
 	mysqli_select_db($conn,"animaldata");
	if(isset($_POST['submit'])) //check if submit button with name submit pressed
	{
		$aname = $_POST['aname'];
		$category = $_POST['category'];
		$description = $_POST['description'];
		$life = $_POST['life'];
		$adate = $_POST['adate'];
		$files = $_FILES['file']; //$_FILES is an associative array containing items uploaded via HTTP POST method
		//print_r($files);
				
		$filename = $files['name']; //original name of the file to be uploaded
		$fileerror = $files['error']; //The error code associated with this file upload.
		$filetmp = $files['tmp_name']; //The temporary filename of the file in which the uploaded file was stored.

		$fileext = explode('.', $filename); //explode file variable and get last element of array it will be the file extension
		$filecheck = strtolower(end($fileext)); /*putting the type of file in lower case by only using the end letters of file and functioning to strtolower  */

		$fileextstored = array('png', 'jpg', 'jpeg'); //in array setting types of filesstored
		if(in_array($filecheck, $fileextstored))
		{
			$destinationfile = 'upload/'.$filename;
			move_uploaded_file($filetmp, $destinationfile); //If match file extension then image will be store in upload file

			$q = "INSERT INTO animalinfo(name, category, image, description, life, adate)VALUES('$aname', '$category', '$destinationfile', '$description', '$life', '$adate')";
    		if(mysqli_query($conn,$q))
				echo "<script type='text/javascript'>alert('Data added successfully.');window.location.href='submission.php';</script>";
			else
				echo "<script type='text/javascript'>alert('Data not added successfully.');window.location.href='submission.php';</script>";
		}
	}


?>