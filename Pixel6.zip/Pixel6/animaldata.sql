-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 02, 2021 at 04:31 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `animaldata`
--

-- --------------------------------------------------------

--
-- Table structure for table `animalinfo`
--

CREATE TABLE IF NOT EXISTS `animalinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `category` varchar(200) NOT NULL,
  `image` varchar(500) NOT NULL,
  `description` varchar(500) NOT NULL,
  `life` varchar(200) NOT NULL,
  `adate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `animalinfo`
--

INSERT INTO `animalinfo` (`id`, `name`, `category`, `image`, `description`, `life`, `adate`) VALUES
(1, 'Giraffe', 'Herbivores', 'upload/giraffe.png', 'Herbivores Animal Giraffe', '10+ Years', '2021-09-02'),
(2, 'Elephant', 'Herbivores', 'upload/elephant.jpg', 'Herbivores Animal Elephant', '10+ Years', '2020-07-16'),
(3, 'Peguin', 'Carnivores', 'upload/Peguin.jpg', 'Carnivores Animal Peguin', '1-5 Years', '2021-08-19'),
(4, 'Tiger', 'Carnivores', 'upload/image.jpg', 'CarnivoresAnimal', '10+ Years', '2021-09-02'),
(5, 'Baby Tiger', 'Carnivores', 'upload/download (2).jpg', 'Carnivores Animal ', '0-1 Years', '2021-09-02'),
(6, 'Shark', 'Carnivores', 'upload/shark-seas.jpg', 'Shark CArnivores Animal', '5-10 Years', '2021-09-02'),
(7, 'Monkey', 'Omnivores', 'upload/monkey.jpg', 'Omnovores Animal Monkey', '5-10 Years', '2021-09-02'),
(8, 'Kiwi', 'Omnivores', 'upload/Kiwi.jpg', 'Kiwi Omnivores Animal', '0-1 Years', '2021-09-02'),
(9, 'Bear', 'Omnivores', 'upload/bear.jpg', 'Bear ANimal', '5-10 Years', '2021-07-14'),
(10, 'Buffalo', 'Herbivores', 'upload/Buffalo.jpg', 'Harbivores Animal', '10+ Years', '2021-09-02'),
(11, 'Bongo', 'Herbivores', 'upload/Bongo1.jpg', 'Harbivores Animal', '5-10 Years', '2021-09-02'),
(12, 'Dog', 'Herbivores', 'upload/Dog1.jpg', 'Dog', '0-1 Years', '2021-09-02'),
(13, 'Turtle', 'Omnivores', 'upload/tortoise-ground-species-Galapagos-Islands-home-archipelago.jpg', 'Omnivores Turtle Animal', '10+ Years', '2021-09-02');
